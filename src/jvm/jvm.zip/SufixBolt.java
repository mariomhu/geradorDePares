package udacity.storm;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.StormSubmitter;
import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.testing.TestWordSpout;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.TopologyBuilder;
import backtype.storm.topology.base.BaseRichSpout;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;
import backtype.storm.utils.Utils;

import java.util.Map;

import java.util.*;


/**
 * A bolt that prints the word and count to redis
 */
public class SufixBolt extends BaseRichBolt
{
    OutputCollector _collector;

    @Override
    public void prepare(
        Map                     map,
        TopologyContext         topologyContext,
        OutputCollector         outputCollector)
    {
    }

    @Override
    public void execute(Tuple tuple)
    {
        int offSet       = 3;
        int posMin       = offSet + 1;
        int parmSearchDist = 1;
        int parmNTerms   = 2;
        int parmDist     = 1;
        double size      = 3;
        double parmFreq  = 0.5;//porcentagem
        double frequencia;

        String separador = " ";
        String separador2= "|";
        String sentence  = tuple.getString(0);
        String[] info    = sentence.split(separador2);
        String chave     = info[0];
        String[] reg1    = info[1].split(separador);
        String[] reg2    = info[2].split(separador);
        int minSize = 0,freq = 0;
        int sufSize1, sufSize2, i, j;
        int encontrados = 0;
        boolean lOk = true;
        boolean lFound = false;
        Random gerador = new Random();
        int[] pos;
        int rand = 0;
        int nTerms;
        int posExiste = -1;
        int randomMax = reg1.length - offSet;

        sufSize1 = reg1.length - posMin;
        sufSize2 = reg2.length - posMin;

        if(sufSize1 <= 0 || sufSize2 <= 0)
            lOk = false;
        if(lOk){
            if(sufSize1 <= sufSize2)
                minSize = sufSize1;
            else
                minSize = sufSize2;

            if(minSize < parmNTerms)
                pos = new int[minSize];
            else
                pos = new int[parmNTerms];

            for(i=0;i<pos.length;i++){
                rand = gerador.nextInt(randomMax)+offSet;
                posExiste = -1;
                for(j=0;j<i;j++){
                    if(rand == pos[j]){
                        posExiste = j;
                        break;
                    }
                }
                if(posExiste == -1)
                    pos[i] = rand;
                else
                    i--;
            }
            for(i=0;i<pos.length;i++){
                for(j=pos[i]-parmDist;j<=pos[i]+parmDist;j++)
                    if (pos[i] >= 0 && pos[i] <= reg1.length && j >= 0 && j <= reg2.length)
                        if(reg1[pos[i]].equals(reg2[j])){
                            lFound = true;
                            encontrados++;
                            break;
                        }
            }
            if((double)((double)encontrados/parmNTerms)>=parmFreq)
                _collector.emit(tuple, new Values(sentence));
            //fazer a busca agora
            //array "pos" com as posições de busca
            //ainda tem que selecionar array com menor tamanho
        }
        else
            pos = new int[1];
    }

    public void declareOutputFields(OutputFieldsDeclarer declarer)
    {
        declarer.declare(new Fields("exclamated-word"));
        // nothing to add - since it is the final bolt
    }
}
