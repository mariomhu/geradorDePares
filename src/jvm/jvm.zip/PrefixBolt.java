package udacity.storm;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.StormSubmitter;
import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.testing.TestWordSpout;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.TopologyBuilder;
import backtype.storm.topology.base.BaseRichSpout;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;
import backtype.storm.utils.Utils;

import java.util.Map;

import java.util.*;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisPubSub;
import com.lambdaworks.redis.RedisClient;
import com.lambdaworks.redis.RedisConnection;


/**
 * A bolt that prints the word and count to redis
 */
public class PrefixBolt extends BaseRichBolt
{
    OutputCollector _collector;
    protected JedisPool pool;

    @Override
    public void prepare(
        Map                     map,
        TopologyContext         topologyContext,
        OutputCollector         outputCollector)
    {
        _collector = outputCollector;
        pool = new JedisPool("127.0.0.1");
    }

    @Override
    public void execute(Tuple tuple)
    {
        Jedis jedis      = pool.getResource();
        int prefSize     = 3;
        double size      = 3;
        double parmFreq  = 0.5;//porcentagem
        double frequencia;
        String separador = " ";
        String separador2= "|";
        String sentence  = tuple.getString(0);
        String[] info    = sentence.split(separador2);
        String chave     = info[0];
        String[] reg1    = info[1].split(separador);
        String[] reg2    = info[2].split(separador);
        int i,j,min1,min2,freq = 0;

        jedis.select(8);
        jedis.set("EXEC","TESTEEE");
        jedis.set("REG1",info[1].split(separador)[0]);
        jedis.set("SENT",sentence +"|"+ Integer.toString(reg1.length)+ " "+Integer.toString(reg2.length)+ " " + Integer.toString(prefSize) );

        if(prefSize + 1 < reg1.length)
            min1 = prefSize + 1;
        else
            min1 = reg1.length;

        if(prefSize + 1 < reg2.length)
            min2 = prefSize + 1;
        else
            min2 = reg2.length;

        for(i=1;i<min1;i++){
            for(j=1;j<min2;j++){
                if(reg1[i].equals(reg2[j]))
                    freq++;
            }
        }
        jedis.set("MIN1",Integer.toString(min1));
        jedis.set("MIN2",Integer.toString(min2));
        frequencia = freq;
        jedis.select(8);
        if(frequencia > 0)
          jedis.set("FREQ",Double.toString(frequencia));
        if(frequencia/size > parmFreq){
            jedis.select(8);
            jedis.set("PAR1",sentence);
            _collector.emit(tuple, new Values(sentence));
        }
        pool.returnResource(jedis);
    }

    public void declareOutputFields(OutputFieldsDeclarer declarer)
    {
      declarer.declare(new Fields("exclamated-word"));
      // nothing to add - since it is the final bolt
    }
}
